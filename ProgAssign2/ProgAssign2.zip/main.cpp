#include <string>
#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

bool ProcessFile(string filename);
int Paint(string stripes, bool debug = false);


void main()
{
	string filename;
	cout << "Please specify a file name: ";
	cin >> filename;

	clock_t beginClock = clock();
	time_t beginTime = time(0);
	char* dtBegin = ctime(&beginTime);
	cout << "Program started at " << dtBegin;


	ProcessFile(filename);

	clock_t endClock = clock();
	time_t endTime = time(0);
	char* dtEnd = ctime(&endTime);
	cout << "Program ended at " << dtEnd;
	double elapsed_secs = double(endClock - beginClock) / CLOCKS_PER_SEC;
	cout << "Running time in seconds: \"" << elapsed_secs << "\"" << endl;

	//Paint("YBYB", true); //OK
	//Paint("BGRGB", true); //OK
	//Paint("YBYCYRY", true); //OK
	//Paint("AABBBCCCDABABBBB", true); //OK

	system("pause");
}

bool ProcessFile(string filename)
{
	string ouputfile = filename + ".output.txt";
	string line;
	ifstream inputFile(filename);
	ofstream outputFile(ouputfile);
	if (inputFile.is_open() && outputFile.is_open())
	{
		while (getline(inputFile, line))
		{
			int numChanges = Paint(line);
			outputFile << numChanges << endl;
		}
		inputFile.close();
		outputFile.close();
		cout << "Output file saved as \"" << ouputfile << "\"" << endl;
	}
	else
	{
		cout << "ERROR!!!: Unable to open file" << endl;
		return false;
	}

	return true;
}

int Paint(string stripes, bool debug)
{
	int prevNumChanges = 0;
	int numChanges = 1;
	string output(stripes.length(), stripes[0]);
	if (debug)
	{
		cout << "00: " << stripes << endl;
		cout << "01: " << output << endl;
	}
	
	int paletteSize = 0;
	char* paletteUsedColors = new char[stripes.length()];

	for (size_t i = 1; i < stripes.length(); i++)
	{
		if (output[i] == stripes[i])
		{
			paletteSize = 0;
			continue;
		}

		char newColor = stripes[i];
		bool colorWasUsed = false;
		for (int arrIndex=paletteSize-1; arrIndex >= 0; arrIndex--)
			if (newColor == paletteUsedColors[arrIndex])
			{
				colorWasUsed = true;
				paletteSize = arrIndex + 1;
				break;
			}

		if (!colorWasUsed)
		{
			numChanges++;
			paletteUsedColors[paletteSize] = newColor;
			paletteSize++;
		}

		output[i] = newColor;
		if (debug && prevNumChanges != numChanges)
		{
			prevNumChanges = numChanges;
			if (numChanges < 10)
				cout << "0" << numChanges << ": " << output << endl;
			else
				cout << numChanges << ": " << output << endl;
		}
	}

	if (debug)
	{
		if (stripes != output)
			cout << "ERROR!!!: " << stripes << " ==> " << output << " ==> " << numChanges << endl;
		else
			cout << stripes << " ==> " << numChanges << endl;
	}

	delete[] paletteUsedColors;
	return numChanges;
}

